﻿using System;
namespace CallApi.Properties
{
    public class Article
    {
        public Article()
        {
        }
    }
}
